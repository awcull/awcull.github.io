// Based on Show Tabs in Process, https://developer.chrome.com/extensions/samples
function init() {
  // Read in JSON data generated from background.js
  var siteList = JSON.parse(localStorage.siteList);
  
  // Create sorted list
  var sortedSites = new Array();
  // Generate sorted list
  for (theSite in siteList) {
   sortedSites.push([theSite, siteList[theSite]]);
  }
  // Sort sites by time
  sortedSites.sort(function(a, b) {return b[1] - a[1];});

  // Set up html
  var outputDiv = document.getElementById("tab-list");
  var titleDiv = document.getElementById("title");
  
  // create title
  titleDiv.innerHTML = "<b>List of sites and time</b>";
  
  // Create rows/cols to store info
  var row = document.createElement("tr");
  var col = document.createElement("td");
  
  // Create headers
  row = document.createElement("tr"); // define row
  col = document.createElement("th"); // define header
  col.appendChild(document.createTextNode("Site"));
  row.appendChild(col);
  col = document.createElement("th"); // define header
  col.appendChild(document.createTextNode("Minutes"));
  row.appendChild(col);
  outputDiv.appendChild(row);
  
  // Loop over sorted sites and create html, site name and time in minutes
  for (var j = 0; j < sortedSites.length; j++) {
   var site = sortedSites[j][0];
   var secToMin = siteList[site] / 60; // Convert seconds to minutes
	// make sure site is not null, had some issue originally with this but should no longer be an issue but better to check
	if (site != null) {
		// create table information
		// Create site name column
		row = document.createElement("tr"); // deinfe row
		col = document.createElement("td"); // define col/cell
		col.appendChild(document.createTextNode(site)); // add site name
		row.appendChild(col); // append to row
		// Create time column
		col = document.createElement("td"); // define col/cell
		col.appendChild(document.createTextNode(secToMin));  // add minutes
		row.appendChild(col); // append to row
		outputDiv.appendChild(row);
   } // end of null check
  } // end of for loop over sorted sites
} // end of init function

document.addEventListener("DOMContentLoaded", init());